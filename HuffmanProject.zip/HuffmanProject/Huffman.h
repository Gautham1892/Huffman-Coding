#include "frequencycounter.h"
// function iterates through the encoded string s
// if s[i]=='1' then move to node->right
// if s[i]=='0' then move to node->left
// if leaf node append the node->data to our output string

string decode_file(struct MinHeapNode* root, string s)
{
    string ans = "";
    struct MinHeapNode* curr = root;
    for (int i=0;i<s.size();i++)
    {
        if (s[i] == '0')
           curr = curr->left;
        else
           curr = curr->right;
  
        // reached leaf node
        if (curr->left==NULL and curr->right==NULL)
        {
            ans += curr->data;
            curr = root;
        }
    }
    // cout<<ans<<endl;
    return ans+'\0';
}


// The main function that builds a Huffman Tree and print codes by traversing the built Huffman Tree
MinHeapNode* HuffmanCodes(char data[], int freq[], int size)

{
	// Construct Huffman Tree
	struct MinHeapNode* root = buildHuffmanTree(data, freq, size);
	// Print Huffman codes using the Huffman tree built above
	int arr[MAX_TREE_HT], top = 0;

	printCodes(root, arr, top);

	return root;
}

//a function to read the given file
void read_file(string filename,char* str)
{
    filename=filename+".txt";
    string s;
    ifstream fp;
    fp.open(filename);
	while (getline(fp,s))
	{
		strcat(str,s.c_str());
	}
    fp.close();
}

// a function to write the encoded message into a file 
void write_file(string s,char str[])
{
    string s_enc=s+"ENC.txt";
    fstream fp_enc;
    fp_enc.open(s_enc);
    for(int i=0;i<strlen(str);i++){
		for(auto j=codes[str[i]].begin();j!=codes[str[i]].end();++j){
			fp_enc << (*j) ;//Writing encoded message into the file
	}
	}
	
	fp_enc.close();
}
// function that displays :
// frequency table
// codes for each character
// encoded message
void display(int c,int freq[], char chr[],char str[]){
    cout<<"Frequency table:"<<endl;
    for(int i=0;i<c;i++){
        cout<<chr[i]<<" = "<<freq[i]<<endl;
    }

    cout<<"\nCodes for individual characters:"<<endl;
    for(auto i=codes.begin();i!=codes.end();++i){
        cout<<(*i).first<<" : ";
        for(auto j=(*i).second.begin();j!=(*i).second.end();++j){
            cout<<(*j);
        }
        cout<<endl;
    }
    
    cout<<"Encoded form:\n";
    for(int i=0;i!=strlen(str);i++){
        for(auto j=codes[str[i]].begin();j!=codes[str[i]].end();++j){
            cout<<(*j);
        }
    }
}