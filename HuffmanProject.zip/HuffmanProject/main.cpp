#include "Huffman.h"
int main(){
    int ch,flag=0;
    char cont = 'y';


    cout<<"************* Huffman Encoding in C++ Project :-) ************"<<endl;;
    cout<< "---project by Gautham--- ";
    cout<<endl<<endl;
    cout<<"Huffman coding is a lossless data compression algorithm."<<endl<<"The idea is to assign variable-length codes to input characters, lengths of the assigned codes are based on the frequencies of corresponding characters."<<endl<<"The most frequent character gets the smallest code and the least frequent character gets the largest code."<<endl;

    cout<<endl;

    while(cont == 'y')
    {

    int c=0;
    string filename;
    char str[1000];
    char chr[100];
    int freq[50];
	map<char,int> frequency;
    cout<<"\n1.INSERT\n2.DISPLAY\n3.DECODE\n4.EXIT\n";
    cin>>ch;
    switch(ch){

        case 1:
            cout<<"Would you like to "<<endl<<" 1. Enter the string to be decoded"<<endl<<" 2. Upload a file?.."<<endl;
            int ch2;
            cin>>ch2;

            switch(ch2){
                    case 1:
                        frequency.clear();
                        codes.clear();
                        cin>>str;
                        string_convertor(str,frequency);
                        freq_calculator(chr,freq,frequency,c);
                        HuffmanCodes(chr,freq,c);

                        flag++;
                        break;
                    case 2:
                        cin>>filename;
                        read_file(filename,str);
                        string_convertor(str,frequency);
                        freq_calculator(chr,freq,frequency,c);
                        HuffmanCodes(chr,freq,c);
                        flag++;
                        break;
                }
            break;

        case 2:
            if(flag>0)
            {
                display(c,freq,chr,str);
            }
            break;

        case 3:
            cout<<"DECODE";
            break;

        case 4:
            cout<<"EXITING...";
            cont='n';
            break;
        default:
            break;



    }


    }

    cin>>cont;
  return 0;

}
